<?php
session_start();

if (!isset($_SESSION['login'])) {
    header('Location: ../../pages/login.php');
    exit();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

require_once __DIR__ . '/../../database/database.php';
require_once __DIR__ . '/admin-crud-helpers.php';
$entities = require __DIR__ . '/admin-crud-config.php';
$entityKey = isset($_GET['entity']) && is_string($_GET['entity']) ? $_GET['entity'] : '';

if (!isset($entities[$entityKey])) {
    http_response_code(404);
    exit('Rubrique d’administration introuvable.');
}

$entity = $entities[$entityKey];
$message = $_SESSION['success'] ?? '';
unset($_SESSION['success']);
$error = '';
$record = null;
$options = [];
$allowedOptions = [];
$editKeys = [];

try {
    foreach ($entity['fields'] as $fieldName => $field) {
        if ($field['type'] === 'select') {
            $optionRows = $connexion->query($field['optionsSql'])->fetchAll(PDO::FETCH_ASSOC);
            $options[$fieldName] = $optionRows;
            $allowedOptions[$fieldName] = array_map('strval', array_column($optionRows, 'value'));
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $csrfToken = isset($_POST['csrf_token']) && is_string($_POST['csrf_token']) ? $_POST['csrf_token'] : '';
        if (!hash_equals($_SESSION['csrf_token'], $csrfToken)) {
            throw new RuntimeException('Le formulaire a expiré. Rechargez la page puis réessayez.');
        }

        $action = isset($_POST['action']) && is_string($_POST['action']) ? $_POST['action'] : '';
        if (!in_array($action, ['create', 'update', 'delete'], true)) {
            throw new RuntimeException('Action non reconnue.');
        }

        $keyValues = [];
        foreach ($entity['keys'] as $keyName) {
            $postedKey = $_POST['key_' . $keyName] ?? null;
            if ($action !== 'create') {
                if (!is_string($postedKey) || filter_var($postedKey, FILTER_VALIDATE_INT) === false) {
                    throw new RuntimeException('Identifiant de ligne invalide.');
                }
                $keyValues[$keyName] = (int) $postedKey;
            }
        }

        if ($action === 'delete') {
            if ($entityKey === 'users' && $keyValues['id_admin'] === (int) $_SESSION['id_admin']) {
                throw new RuntimeException('Vous ne pouvez pas supprimer votre propre compte.');
            }
            if (!adminDeleteRecord($connexion, $entity, $keyValues)) {
                throw new RuntimeException('La ligne à supprimer est introuvable.');
            }
            $_SESSION['success'] = 'La ligne a été supprimée.';
            header('Location: crud.php?entity=' . rawurlencode($entityKey));
            exit();
        }

        adminSaveRecord($connexion, $entity, $_POST, $allowedOptions, $action, $keyValues);

        $_SESSION['success'] = $action === 'create' ? 'L’entrée a été ajoutée.' : 'Les modifications ont été enregistrées.';
        header('Location: crud.php?entity=' . rawurlencode($entityKey));
        exit();
    }

    if (isset($_GET['edit'])) {
        foreach ($entity['keys'] as $keyName) {
            $value = $_GET['key_' . $keyName] ?? null;
            if (!is_string($value) || filter_var($value, FILTER_VALIDATE_INT) === false) {
                throw new RuntimeException('Identifiant de ligne invalide.');
            }
            $editKeys[$keyName] = (int) $value;
        }
        $conditions = [];
        foreach ($entity['keys'] as $keyName) {
            $conditions[] = '`' . $keyName . '` = :where_' . $keyName;
        }
        $statement = $connexion->prepare('SELECT * FROM `' . $entity['table'] . '` WHERE ' . implode(' AND ', $conditions));
        $whereValues = [];
        foreach ($editKeys as $name => $value) {
            $whereValues['where_' . $name] = $value;
        }
        $statement->execute($whereValues);
        $record = $statement->fetch(PDO::FETCH_ASSOC);
        if (!$record) {
            throw new RuntimeException('La ligne à modifier est introuvable.');
        }
    }

    $rows = $connexion->query($entity['listSql'])->fetchAll(PDO::FETCH_ASSOC);
} catch (RuntimeException $exception) {
    $error = $exception->getMessage();
} catch (PDOException $exception) {
    error_log('Erreur CRUD JO 2028 (' . $entityKey . '): ' . $exception->getMessage());
    $error = 'Opération impossible. Vérifiez les données liées et réessayez.';
}

function adminCrudUrl(string $entityKey, array $keys = []): string
{
    $query = ['entity' => $entityKey, 'edit' => '1'];
    foreach ($keys as $name => $value) {
        $query['key_' . $name] = (string) $value;
    }
    return 'crud.php?' . http_build_query($query);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/normalize.css">
    <link rel="stylesheet" href="../../css/styles-computer.css">
    <link rel="stylesheet" href="../../css/styles-responsive.css">
    <title>Gestion <?= adminEscape($entity['title']) ?> - JO 2028</title>
</head>
<body>
    <header><nav><ul class="menu">
        <li><a href="admin.php">Accueil administration</a></li>
        <?php foreach ($entities as $key => $item): ?>
            <li><a href="crud.php?entity=<?= adminEscape($key) ?>">Gestion <?= adminEscape($item['title']) ?></a></li>
        <?php endforeach; ?>
        <li><a href="admin-sports/manage-sports.php">Gestion Sports</a></li>
        <li><a href="../logout.php">Déconnexion</a></li>
    </ul></nav></header>
    <main>
        <h1>Gestion <?= adminEscape($entity['title']) ?></h1>
        <?php if ($message !== ''): ?><p role="status"><?= adminEscape($message) ?></p><?php endif; ?>
        <?php if ($error !== ''): ?><p role="alert"><?= adminEscape($error) ?></p><?php endif; ?>

        <h2><?= $record ? 'Modifier une entrée' : 'Ajouter une entrée' ?></h2>
        <form method="post" action="crud.php?entity=<?= adminEscape($entityKey) ?>">
            <input type="hidden" name="csrf_token" value="<?= adminEscape($_SESSION['csrf_token']) ?>">
            <input type="hidden" name="action" value="<?= $record ? 'update' : 'create' ?>">
            <?php foreach ($editKeys as $name => $value): ?>
                <input type="hidden" name="key_<?= adminEscape($name) ?>" value="<?= adminEscape($value) ?>">
            <?php endforeach; ?>
            <?php foreach ($entity['fields'] as $name => $field): ?>
                <label for="<?= adminEscape($name) ?>"><?= adminEscape($field['label']) ?></label>
                <?php if ($field['type'] === 'select'): ?>
                    <select id="<?= adminEscape($name) ?>" name="<?= adminEscape($name) ?>" <?= !empty($field['required']) ? 'required' : '' ?>>
                        <option value="">Sélectionner…</option>
                        <?php foreach ($options[$name] as $option): ?>
                            <option value="<?= adminEscape($option['value']) ?>" <?= isset($record[$name]) && (string) $record[$name] === (string) $option['value'] ? 'selected' : '' ?>><?= adminEscape($option['label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php else: ?>
                    <input type="<?= adminEscape($field['type']) ?>" id="<?= adminEscape($name) ?>" name="<?= adminEscape($name) ?>"
                        value="<?= $field['type'] === 'password' ? '' : adminEscape($record[$name] ?? '') ?>"
                        <?= !empty($field['required']) && !($record && $field['type'] === 'password') ? 'required' : '' ?>
                        <?= $field['type'] === 'time' ? 'step="1"' : '' ?>
                        <?= $field['type'] === 'password' && $record ? 'autocomplete="new-password"' : '' ?>>
                    <?php if ($field['type'] === 'password' && $record): ?><small>Laisser vide pour conserver le mot de passe actuel.</small><?php endif; ?>
                <?php endif; ?>
            <?php endforeach; ?>
            <input type="submit" value="<?= $record ? 'Enregistrer' : 'Ajouter' ?>">
            <?php if ($record): ?><p><a href="crud.php?entity=<?= adminEscape($entityKey) ?>">Annuler la modification</a></p><?php endif; ?>
        </form>

        <h2>Entrées existantes</h2>
        <?php if (empty($rows)): ?>
            <p>Aucune entrée trouvée.</p>
        <?php else: ?>
            <table><thead><tr>
                <?php foreach ($entity['columns'] as $label => $fieldName): ?><th><?= adminEscape($label) ?></th><?php endforeach; ?>
                <th>Actions</th>
            </tr></thead><tbody>
                <?php foreach ($rows as $row): ?>
                    <?php $rowKeys = []; foreach ($entity['keys'] as $keyName) { $rowKeys[$keyName] = $row[$keyName]; } ?>
                    <tr>
                        <?php foreach ($entity['columns'] as $fieldName): ?><td><?= adminEscape($row[$fieldName] ?? '') ?></td><?php endforeach; ?>
                        <td>
                            <?php if (!($entityKey === 'users' && (int) $row['id_admin'] === (int) $_SESSION['id_admin'])): ?>
                                <a href="<?= adminEscape(adminCrudUrl($entityKey, $rowKeys)) ?>">Modifier</a>
                                <form method="post" action="crud.php?entity=<?= adminEscape($entityKey) ?>" onsubmit="return confirm('Confirmer la suppression ?')">
                                    <input type="hidden" name="csrf_token" value="<?= adminEscape($_SESSION['csrf_token']) ?>">
                                    <input type="hidden" name="action" value="delete">
                                    <?php foreach ($rowKeys as $name => $value): ?><input type="hidden" name="key_<?= adminEscape($name) ?>" value="<?= adminEscape($value) ?>"><?php endforeach; ?>
                                    <button type="submit">Supprimer</button>
                                </form>
                            <?php else: ?>
                                <span>Compte connecté</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody></table>
        <?php endif; ?>
        <p class="paragraph-link"><a class="link-home" href="admin.php">Accueil administration</a></p>
    </main>
    <footer><figure><img src="../../img/logo-jo.png" alt="Logo Jeux Olympiques - Los Angeles 2028"></figure></footer>
</body>
</html>

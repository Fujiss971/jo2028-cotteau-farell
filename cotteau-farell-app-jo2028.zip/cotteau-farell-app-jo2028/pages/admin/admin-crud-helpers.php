<?php

function adminNormalizeInput(array $fields, array $input, array $allowedOptions = [], bool $isUpdate = false): array
{
    $values = [];
    $errors = [];

    foreach ($fields as $name => $field) {
        $value = isset($input[$name]) && is_string($input[$name]) ? trim($input[$name]) : '';
        $required = !empty($field['required']) && !($isUpdate && $field['type'] === 'password' && $value === '');

        if ($required && $value === '') {
            $errors[] = 'Le champ « ' . $field['label'] . ' » est obligatoire.';
            continue;
        }
        if ($value === '') {
            continue;
        }
        if ($field['type'] === 'select' && !in_array($value, $allowedOptions[$name] ?? [], true)) {
            $errors[] = 'La valeur sélectionnée pour « ' . $field['label'] . ' » est invalide.';
            continue;
        }
        if ($field['type'] === 'date') {
            $date = DateTime::createFromFormat('!Y-m-d', $value);
            if (!$date || $date->format('Y-m-d') !== $value) {
                $errors[] = 'La date indiquée pour « ' . $field['label'] . ' » est invalide.';
                continue;
            }
        }
        if ($field['type'] === 'time' && !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/', $value)) {
            $errors[] = 'L’heure indiquée pour « ' . $field['label'] . ' » est invalide.';
            continue;
        }
        if ($field['type'] === 'time' && strlen($value) === 5) {
            $value .= ':00'; // HH:MM devient HH:MM:SS, format stocké par MySQL (utile pour détecter les doublons)
        }
        if ($field['type'] === 'password') {
            if (strlen($value) < 8) {
                $errors[] = 'Le mot de passe doit contenir au moins 8 caractères.';
                continue;
            }
            $values[$name] = password_hash($value, PASSWORD_BCRYPT);
            continue;
        }
        if ($field['type'] === 'select' && filter_var($value, FILTER_VALIDATE_INT) === false) {
            $errors[] = 'La valeur sélectionnée pour « ' . $field['label'] . ' » est invalide.';
            continue;
        }

        $values[$name] = $value;
    }

    return ['values' => $values, 'errors' => $errors];
}

function adminEscape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function adminSaveRecord(PDO $connexion, array $entity, array $input, array $allowedOptions, string $action, array $keyValues = []): void
{
    if (!in_array($action, ['create', 'update'], true)) {
        throw new RuntimeException('Action d’enregistrement invalide.');
    }

    $whereParts = [];
    $whereValues = [];
    if ($action === 'update') {
        foreach ($entity['keys'] as $keyName) {
            if (!array_key_exists($keyName, $keyValues)) {
                throw new RuntimeException('Identifiant de ligne manquant.');
            }
            $whereParts[] = '`' . $keyName . '` = :where_' . $keyName;
            $whereValues['where_' . $keyName] = $keyValues[$keyName];
        }
        $statement = $connexion->prepare('SELECT 1 FROM `' . $entity['table'] . '` WHERE ' . implode(' AND ', $whereParts));
        $statement->execute($whereValues);
        if (!$statement->fetchColumn()) {
            throw new RuntimeException('La ligne à modifier est introuvable.');
        }
    }

    $normalized = adminNormalizeInput($entity['fields'], $input, $allowedOptions, $action === 'update');
    if ($normalized['errors']) {
        throw new RuntimeException(implode(' ', $normalized['errors']));
    }
    $values = $normalized['values'];

    foreach ($entity['unique'] as $uniqueFields) {
        $uniqueParts = [];
        $uniqueValues = [];
        foreach ($uniqueFields as $fieldName) {
            $uniqueParts[] = 'UPPER(TRIM(`' . $fieldName . '`)) = UPPER(TRIM(:unique_' . $fieldName . '))';
            $uniqueValues['unique_' . $fieldName] = $values[$fieldName];
        }
        $duplicateSql = 'SELECT 1 FROM `' . $entity['table'] . '` WHERE ' . implode(' AND ', $uniqueParts);
        if ($action === 'update') {
            $excludeParts = [];
            foreach ($entity['keys'] as $keyName) {
                $excludeParts[] = '`' . $keyName . '` = :exclude_' . $keyName;
                $uniqueValues['exclude_' . $keyName] = $keyValues[$keyName];
            }
            $duplicateSql .= ' AND NOT (' . implode(' AND ', $excludeParts) . ')';
        }
        $duplicate = $connexion->prepare($duplicateSql);
        $duplicate->execute($uniqueValues);
        if ($duplicate->fetchColumn()) {
            throw new RuntimeException('Une entrée identique existe déjà.');
        }
    }

    if ($action === 'create') {
        $columns = array_keys($values);
        $placeholders = array_map(function ($name) { return ':' . $name; }, $columns);
        $sql = 'INSERT INTO `' . $entity['table'] . '` (`' . implode('`, `', $columns) . '`) VALUES (' . implode(', ', $placeholders) . ')';
        $connexion->prepare($sql)->execute($values);
        return;
    }

    if (!$values) {
        throw new RuntimeException('Aucune modification à enregistrer.');
    }

    $setParts = [];
    $updateValues = [];
    foreach ($values as $fieldName => $value) {
        $setParts[] = '`' . $fieldName . '` = :value_' . $fieldName;
        $updateValues['value_' . $fieldName] = $value;
    }
    $statement = $connexion->prepare('UPDATE `' . $entity['table'] . '` SET ' . implode(', ', $setParts) . ' WHERE ' . implode(' AND ', $whereParts));
    $statement->execute($updateValues + $whereValues);
}

function adminDeleteRecord(PDO $connexion, array $entity, array $keyValues): bool
{
    $conditions = [];
    $values = [];
    foreach ($entity['keys'] as $keyName) {
        if (!array_key_exists($keyName, $keyValues)) {
            throw new RuntimeException('Identifiant de ligne manquant.');
        }
        $conditions[] = '`' . $keyName . '` = :where_' . $keyName;
        $values['where_' . $keyName] = $keyValues[$keyName];
    }

    $statement = $connexion->prepare('DELETE FROM `' . $entity['table'] . '` WHERE ' . implode(' AND ', $conditions));
    $statement->execute($values);
    return $statement->rowCount() === 1;
}

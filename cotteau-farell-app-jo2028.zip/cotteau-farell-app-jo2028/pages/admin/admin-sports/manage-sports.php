<?php
session_start();

// Vérifiez si l'utilisateur est connecté
if (!isset($_SESSION['login'])) {
    header('Location: ../../../index.php');
    exit();
}

$login = $_SESSION['login'];
$nom_utilisateur = $_SESSION['prenom_admin'];
$prenom_utilisateur = $_SESSION['nom_admin'];

// Générer un token CSRF si ce n'est pas déjà fait
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Génère un token CSRF
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../../css/normalize.css">
    <link rel="stylesheet" href="../../../css/styles-computer.css">
    <link rel="stylesheet" href="../../../css/styles-responsive.css">
    <link rel="shortcut icon" href="../../../img/favicon.ico" type="image/x-icon">
    <title>Liste des Sports - Jeux Olympiques - Los Angeles 2028</title>
</head>

<body>
    <header>
        <nav>
            <ul class="menu">
                <li><a href="../admin.php">Accueil Administration</a></li>
                <li><a href="manage-sports.php">Gestion Sports</a></li>
                <li><a href="../crud.php?entity=users">Gestion Administrateurs</a></li>
                <li><a href="../crud.php?entity=places">Gestion Lieux</a></li>
                <li><a href="../crud.php?entity=countries">Gestion Pays</a></li>
                <li><a href="../crud.php?entity=events">Gestion Calendrier</a></li>
                <li><a href="../crud.php?entity=athletes">Gestion Athlètes</a></li>
                <li><a href="../crud.php?entity=genders">Gestion Genres</a></li>
                <li><a href="../crud.php?entity=results">Gestion Résultats</a></li>
                <li><a href="../../logout.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h1>Liste des Sports</h1>
        <div class="action-buttons">
            <button onclick="openAddSportForm()">Ajouter un Sport</button>
        </div>
        
        <!-- Tableau des sports -->
        <?php
        require_once("../../../database/database.php");

        try {
            // Requête pour récupérer la liste des sports depuis la base de données
            $query = "SELECT * FROM SPORT ORDER BY nom_sport";
            $statement = $connexion->prepare($query);
            $statement->execute();

            // Vérifier s'il y a des résultats
            if ($statement->rowCount() > 0) {
                echo "<table><tr><th>Sport</th><th>Modifier</th><th>Supprimer</th></tr>";

                // Afficher les données dans un tableau
                while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['nom_sport'], ENT_QUOTES, 'UTF-8') . "</td>";
                    echo "<td><button onclick='openModifySportForm({$row['id_sport']})'>Modifier</button></td>";
                    echo "<td><form method='post' action='delete-sport.php' onsubmit='return confirm(\"Êtes-vous sûr de vouloir supprimer ce sport ?\")'>";
                    echo "<input type='hidden' name='csrf_token' value='" . htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') . "'>";
                    echo "<input type='hidden' name='id_sport' value='" . (int) $row['id_sport'] . "'>";
                    echo "<button type='submit'>Supprimer</button></form></td>";
                    echo "</tr>";
                }

                echo "</table>";
            } else {
                echo "<p>Aucun sport trouvé.</p>";
            }
        } catch (PDOException $e) {
            echo "Erreur : " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
        }
        ?>
        
        <p class="paragraph-link">
            <a class="link-home" href="../admin.php">Accueil administration</a>
        </p>
    </main>

    <footer>
        <figure>
            <img src="../../../img/logo-jo.png" alt="logo Jeux Olympiques - Los Angeles 2028">
        </figure>
    </footer>

    <script>
        function openAddSportForm() {
            window.location.href = 'add-sport.php';
        }

        function openModifySportForm(id_sport) {
            window.location.href = 'modify-sport.php?id_sport=' + id_sport;
        }
    </script>
</body>

</html>
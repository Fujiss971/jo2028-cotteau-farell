<?php
session_start();
require_once("../../../database/database.php");

// Vérifiez si l'utilisateur est connecté
if (!isset($_SESSION['login'])) {
    header('Location: ../../../index.php');
    exit();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Vérifiez si l'ID du sport est fourni dans l'URL
if (!isset($_GET['id_sport'])) {
    $_SESSION['error'] = "ID du sport manquant.";
    header("Location: manage-sports.php");
    exit();
}

$id_sport = filter_input(INPUT_GET, 'id_sport', FILTER_VALIDATE_INT);

// Vérifiez si l'ID du sport est un entier valide
if (!$id_sport && $id_sport !== 0) {
    $_SESSION['error'] = "ID du sport invalide.";
    header("Location: manage-sports.php");
    exit();
}

// Vider les messages de succès précédents
if (isset($_SESSION['success'])) {
    unset($_SESSION['success']);
}

// Récupérez les informations du sport pour affichage dans le formulaire
try {
    $querySport = "SELECT nom_sport FROM SPORT WHERE id_sport = :idSport";
    $statementSport = $connexion->prepare($querySport);
    $statementSport->bindParam(":idSport", $id_sport, PDO::PARAM_INT);
    $statementSport->execute();

    if ($statementSport->rowCount() > 0) {
        $sport = $statementSport->fetch(PDO::FETCH_ASSOC);
    } else {
        $_SESSION['error'] = "Sport non trouvé.";
        header("Location: manage-sports.php");
        exit();
    }
} catch (PDOException $e) {
    $_SESSION['error'] = "Erreur de base de données : " . $e->getMessage();
    header("Location: manage-sports.php");
    exit();
}

// Vérifiez si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['csrf_token'], $_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $_SESSION['error'] = "Token CSRF invalide.";
        header("Location: modify-sport.php?id_sport=$id_sport");
        exit();
    }

    $nomSport = isset($_POST['nomSport']) && is_string($_POST['nomSport']) ? trim($_POST['nomSport']) : '';

    // Vérifiez si le nom du sport est vide
    if (empty($nomSport)) {
        $_SESSION['error'] = "Le nom du sport ne peut pas être vide.";
        header("Location: modify-sport.php?id_sport=$id_sport");
        exit();
    }

    try {
        // Vérifiez si le sport existe déjà
        $queryCheck = "SELECT id_sport FROM SPORT WHERE UPPER(TRIM(nom_sport)) = UPPER(TRIM(:nomSport)) AND id_sport <> :idSport";
        $statementCheck = $connexion->prepare($queryCheck);
        $statementCheck->execute(['nomSport' => $nomSport, 'idSport' => $id_sport]);

        if ($statementCheck->fetchColumn()) {
            $_SESSION['error'] = "Le sport existe déjà.";
            header("Location: modify-sport.php?id_sport=$id_sport");
            exit();
        }

        // Requête pour mettre à jour le sport
        $query = "UPDATE SPORT SET nom_sport = :nomSport WHERE id_sport = :idSport";
        $statement = $connexion->prepare($query);
        $statement->bindParam(":nomSport", $nomSport, PDO::PARAM_STR);
        $statement->bindParam(":idSport", $id_sport, PDO::PARAM_INT);

        // Exécutez la requête
        if ($statement->execute()) {
            $_SESSION['success'] = "Le sport a été modifié avec succès.";
            header("Location: manage-sports.php");
            exit();
        } else {
            $_SESSION['error'] = "Erreur lors de la modification du sport.";
            header("Location: modify-sport.php?id_sport=$id_sport");
            exit();
        }
    } catch (PDOException $e) {
        error_log("Erreur lors de la modification d'un sport : " . $e->getMessage());
        $_SESSION['error'] = "Erreur de base de données lors de la modification du sport.";
        header("Location: modify-sport.php?id_sport=$id_sport");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../../css/normalize.css">
    <link rel="stylesheet" href="../../../css/styles-computer.css">
    <link rel="stylesheet" href="../../../css/styles-responsive.css">
    <link rel="shortcut icon" href="../../../img/favicon.ico" type="image/x-icon">
    <title>Modifier un Sport - Jeux Olympiques - Los Angeles 2028</title>
</head>

<body>
    <header>
        <nav>
            <!-- Menu vers les pages sports, events, et results -->
            <ul class="menu">
                <li><a href="../admin.php">Accueil Administration</a></li>
                <li><a href="manage-sports.php">Gestion Sports</a></li>
                <li><a href="../crud.php?entity=users">Gestion Administrateurs</a></li>
                <li><a href="../crud.php?entity=places">Gestion Lieux</a></li>
                <li><a href="../crud.php?entity=countries">Gestion Pays</a></li>
                <li><a href="../crud.php?entity=events">Gestion Calendrier</a></li>
                <li><a href="../crud.php?entity=athletes">Gestion Athlètes</a></li>
                <li><a href="../crud.php?entity=genders">Gestion Genres</a></li>
                <li><a href="../crud.php?entity=results">Gestion Résultats</a></li>
                <li><a href="../../logout.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h1>Modifier un Sport</h1>
        
        <!-- Affichage des messages d'erreur ou de succès -->
        <?php
        if (isset($_SESSION['error'])) {
            echo '<p style="color: red;">' . htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') . '</p>';
            unset($_SESSION['error']);
        }
        if (isset($_SESSION['success'])) {
            echo '<p style="color: green;">' . htmlspecialchars($_SESSION['success'], ENT_QUOTES, 'UTF-8') . '</p>';
            unset($_SESSION['success']);
        }
        ?>

        <form action="modify-sport.php?id_sport=<?php echo $id_sport; ?>" method="post"
            onsubmit="return confirm('Êtes-vous sûr de vouloir modifier ce sport?')">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
            <label for="nomSport">Nom du Sport :</label>
            <input type="text" name="nomSport" id="nomSport"
                value="<?php echo htmlspecialchars($sport['nom_sport'], ENT_QUOTES, 'UTF-8'); ?>" required>
            <input type="submit" value="Modifier le Sport">
        </form>

        <p class="paragraph-link">
            <a class="link-home" href="manage-sports.php">Retour à la gestion des sports</a>
        </p>
    </main>

    <footer>
        <figure>
            <img src="../../../img/logo-jo.png" alt="logo Jeux Olympiques - Los Angeles 2028">
        </figure>
    </footer>
</body>

</html>

<?php
session_start();
require_once("../../../database/database.php");

// Vérifiez si l'utilisateur est connecté
if (!isset($_SESSION['login'])) {
    header('Location: ../../../index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: manage-sports.php');
    exit();
}

if (!isset($_POST['csrf_token'], $_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $_SESSION['error'] = "Token CSRF invalide.";
    header('Location: manage-sports.php');
    exit();
}

if (!isset($_POST['id_sport'])) {
    $_SESSION['error'] = "ID du sport manquant.";
    header("Location: manage-sports.php");
    exit();
} else {
    $id_sport = filter_input(INPUT_POST, 'id_sport', FILTER_VALIDATE_INT);

    if ($id_sport === false || $id_sport === null || $id_sport < 1) {
        $_SESSION['error'] = "ID du sport invalide.";
        header("Location: manage-sports.php");
        exit();
    } else {
        try {
            // Préparez la requête SQL pour supprimer le sport
            $sql = "DELETE FROM SPORT WHERE id_sport = :id_sport";
            // Exécutez la requête SQL avec le paramètre
            $statement = $connexion->prepare($sql);
            $statement->bindParam(':id_sport', $id_sport, PDO::PARAM_INT);
            $statement->execute();

            $_SESSION['success'] = $statement->rowCount() === 1
                ? "Le sport a été supprimé avec succès."
                : "Aucun sport correspondant n'a été trouvé.";

            // Redirigez vers la page précédente après la suppression
            header('Location: manage-sports.php');
            exit();
        } catch (PDOException $e) {
            $_SESSION['error'] = "Erreur lors de la suppression du sport : " . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
            header('Location: manage-sports.php');
            exit();
        }
    }
}

// Afficher les erreurs en PHP (fonctionne à condition d’avoir activé l’option en local)
error_reporting(E_ALL);
ini_set("display_errors", 1);
?>
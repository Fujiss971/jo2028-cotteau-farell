<?php
session_start();
require_once("../../../database/database.php");

// Vérifiez si l'utilisateur est connecté
if (!isset($_SESSION['login'])) {
    header('Location: ../../../index.php');
    exit();
}

// Générer un token CSRF si ce n'est pas déjà fait
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // Génère un token CSRF sécurisé
}

// Vérifiez si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Vérification du token CSRF
    if (!isset($_POST['csrf_token'], $_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $_SESSION['error'] = "Token CSRF invalide.";
        header("Location: add-sport.php");
        exit();
    }

    $nomSport = isset($_POST['nomSport']) && is_string($_POST['nomSport']) ? trim($_POST['nomSport']) : '';

    // Vérifiez si le nom du sport est vide
    if (empty($nomSport)) {
        $_SESSION['error'] = "Le nom du sport ne peut pas être vide.";
        header("Location: add-sport.php");
        exit();
    }

    try {
        // Vérifiez si le sport existe déjà
        $queryCheck = "SELECT id_sport FROM SPORT WHERE UPPER(TRIM(nom_sport)) = UPPER(TRIM(:nomSport))";
        $statementCheck = $connexion->prepare($queryCheck);
        $statementCheck->execute(['nomSport' => $nomSport]);

        if ($statementCheck->fetchColumn()) {
            $_SESSION['error'] = "Le sport existe déjà.";
            header("Location: add-sport.php");
            exit();
        } else {
            // Requête pour ajouter un sport
            $query = "INSERT INTO SPORT (nom_sport) VALUES (:nomSport)";
            $statement = $connexion->prepare($query);
            $statement->bindParam(":nomSport", $nomSport, PDO::PARAM_STR);

            // Exécutez la requête
            if ($statement->execute()) {
                $_SESSION['success'] = "Le sport a été ajouté avec succès.";
                header("Location: manage-sports.php");
                exit();
            } else {
                $_SESSION['error'] = "Erreur lors de l'ajout du sport.";
                header("Location: add-sport.php");
                exit();
            }
        }
    } catch (PDOException $e) {
        error_log("Erreur lors de l'ajout d'un sport : " . $e->getMessage());
        $_SESSION['error'] = "Erreur de base de données lors de l'ajout du sport.";
        header("Location: add-sport.php");
        exit();
    }
}

// Afficher les erreurs en PHP (fonctionne à condition d’avoir activé l’option en local)
error_reporting(E_ALL);
ini_set("display_errors", 1);
?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../../css/normalize.css">
    <link rel="stylesheet" href="../../../css/styles-computer.css">
    <link rel="stylesheet" href="../../../css/styles-responsive.css">
    <link rel="shortcut icon" href="../../../img/favicon.ico" type="image/x-icon">
    <title>Ajouter un Sport - Jeux Olympiques - Los Angeles 2028</title>
    <style>
        /* Ajoutez votre style CSS ici */
    </style>
</head>

<body>
    <header>
        <nav>
            <!-- Menu vers les pages sports, events, et results -->
            <ul class="menu">
                <li><a href="../admin.php">Accueil Administration</a></li>
                <li><a href="manage-sports.php">Gestion Sports</a></li>
                <li><a href="../crud.php?entity=users">Gestion Administrateurs</a></li>
                <li><a href="../crud.php?entity=places">Gestion Lieux</a></li>
                <li><a href="../crud.php?entity=countries">Gestion Pays</a></li>
                <li><a href="../crud.php?entity=events">Gestion Calendrier</a></li>
                <li><a href="../crud.php?entity=athletes">Gestion Athlètes</a></li>
                <li><a href="../crud.php?entity=genders">Gestion Genres</a></li>
                <li><a href="../crud.php?entity=results">Gestion Résultats</a></li>
                <li><a href="../../logout.php">Déconnexion</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h1>Ajouter un Sport</h1>
        <?php
        if (isset($_SESSION['error'])) {
            echo '<p style="color: red;">' . htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') . '</p>';
            unset($_SESSION['error']);
        }
        if (isset($_SESSION['success'])) {
            echo '<p style="color: green;">' . htmlspecialchars($_SESSION['success'], ENT_QUOTES, 'UTF-8') . '</p>';
            unset($_SESSION['success']);
        }
        ?>
        <form action="add-sport.php" method="post" onsubmit="return confirm('Êtes-vous sûr de vouloir ajouter ce sport ?')">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
            <label for="nomSport">Nom du Sport :</label>
            <input type="text" name="nomSport" id="nomSport" required>
            <input type="submit" value="Ajouter le Sport">
        </form>
        <p class="paragraph-link">
            <a class="link-home" href="manage-sports.php">Retour à la gestion des sports</a>
        </p>
    </main>

    <footer>
        <figure>
            <img src="../../../img/logo-jo.png" alt="logo Jeux Olympiques - Los Angeles 2028">
        </figure>
    </footer>

</body>

</html>

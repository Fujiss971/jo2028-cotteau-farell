# Tests de l’administration JO 2028

Les tests couvrent la validation des formulaires, les mots de passe BCrypt et les opérations CRUD (création, lecture, modification et suppression), y compris l’identifiant composite des résultats.

Depuis PowerShell avec PHP MAMP 8.3 :

```powershell
& 'C:\MAMP\bin\php\php8.3.1\php.exe' `
  -d extension_dir='C:\MAMP\bin\php\php8.3.1\ext' `
  -d extension=php_pdo_sqlite.dll `
  tests\run.php
```

SQLite est utilisé en mémoire pour que ces tests ne modifient pas la base de données du projet. Les tests du site avec MySQL restent à faire après l’import des fichiers `database\db-jo.sql` et `database\test-data-jo.sql`.

<?php
require_once __DIR__ . '/../pages/admin/admin-crud-helpers.php';

$tests = [];

$tests['les champs obligatoires sont nettoyés et contrôlés'] = function () {
    $fields = ['nom' => ['label' => 'Nom', 'type' => 'text', 'required' => true]];
    $valid = adminNormalizeInput($fields, ['nom' => '  Martin  ']);
    if ($valid['errors'] || $valid['values']['nom'] !== 'Martin') {
        throw new RuntimeException('A valid required field was not normalized.');
    }

    $invalid = adminNormalizeInput($fields, ['nom' => '   ']);
    if (!$invalid['errors']) {
        throw new RuntimeException('An empty required field was accepted.');
    }
};

$tests['les sélections refusent les identifiants non autorisés'] = function () {
    $fields = ['id_pays' => ['label' => 'Pays', 'type' => 'select', 'required' => true]];
    $valid = adminNormalizeInput($fields, ['id_pays' => '2'], ['id_pays' => ['1', '2']]);
    if ($valid['errors'] || $valid['values']['id_pays'] !== '2') {
        throw new RuntimeException('A valid select option was rejected.');
    }

    $invalid = adminNormalizeInput($fields, ['id_pays' => '999'], ['id_pays' => ['1', '2']]);
    if (!$invalid['errors']) {
        throw new RuntimeException('An unlisted select identifier was accepted.');
    }
};

$tests['les dates et heures d’épreuve sont contrôlées'] = function () {
    $fields = [
        'date_epreuve' => ['label' => 'Date', 'type' => 'date', 'required' => true],
        'heure_epreuve' => ['label' => 'Heure', 'type' => 'time', 'required' => true],
    ];
    $valid = adminNormalizeInput($fields, ['date_epreuve' => '2028-07-20', 'heure_epreuve' => '14:30']);
    if ($valid['errors']) {
        throw new RuntimeException('A valid event date and time was rejected.');
    }

    $invalid = adminNormalizeInput($fields, ['date_epreuve' => '2028-02-30', 'heure_epreuve' => '25:61']);
    if (count($invalid['errors']) !== 2) {
        throw new RuntimeException('Invalid event date/time was accepted.');
    }
};

$tests['les mots de passe administrateur sont hachés avec BCrypt'] = function () {
    $fields = ['password' => ['label' => 'Mot de passe', 'type' => 'password', 'required' => true]];
    $valid = adminNormalizeInput($fields, ['password' => 'motdepasse-solide']);
    $hash = $valid['values']['password'] ?? '';
    if ($valid['errors'] || strpos($hash, '$2y$') !== 0 || !password_verify('motdepasse-solide', $hash)) {
        throw new RuntimeException('The administrator password was not BCrypt-hashed.');
    }

    $update = adminNormalizeInput($fields, ['password' => ''], [], true);
    if ($update['errors'] || $update['values']) {
        throw new RuntimeException('An empty update password should preserve the existing hash.');
    }
};

$makeCountriesDatabase = function (): PDO {
    $connexion = new PDO('sqlite::memory:');
    $connexion->exec('CREATE TABLE PAYS (id_pays INTEGER PRIMARY KEY AUTOINCREMENT, nom_pays TEXT NOT NULL)');
    return $connexion;
};
$countryEntity = [
    'table' => 'PAYS',
    'keys' => ['id_pays'],
    'fields' => ['nom_pays' => ['label' => 'Nom du pays', 'type' => 'text', 'required' => true]],
    'unique' => [['nom_pays']],
];

$tests['l’ajout est lisible et refuse les doublons'] = function () use ($makeCountriesDatabase, $countryEntity) {
    $connexion = $makeCountriesDatabase();
    adminSaveRecord($connexion, $countryEntity, ['nom_pays' => 'Canada'], [], 'create');
    $name = $connexion->query('SELECT nom_pays FROM PAYS')->fetchColumn();
    if ($name !== 'Canada') {
        throw new RuntimeException('The created country could not be read back.');
    }

    try {
        adminSaveRecord($connexion, $countryEntity, ['nom_pays' => ' canada '], [], 'create');
        throw new RuntimeException('A duplicate country was accepted.');
    } catch (RuntimeException $exception) {
        if ($exception->getMessage() !== 'Une entrée identique existe déjà.') {
            throw $exception;
        }
    }
};

$tests['la modification met à jour sans se compter comme doublon'] = function () use ($makeCountriesDatabase, $countryEntity) {
    $connexion = $makeCountriesDatabase();
    adminSaveRecord($connexion, $countryEntity, ['nom_pays' => 'France'], [], 'create');
    adminSaveRecord($connexion, $countryEntity, ['nom_pays' => 'Canada'], [], 'create');
    adminSaveRecord($connexion, $countryEntity, ['nom_pays' => 'France'], [], 'update', ['id_pays' => 1]);

    try {
        adminSaveRecord($connexion, $countryEntity, ['nom_pays' => 'Canada'], [], 'update', ['id_pays' => 1]);
        throw new RuntimeException('A duplicate country was accepted during update.');
    } catch (RuntimeException $exception) {
        if ($exception->getMessage() !== 'Une entrée identique existe déjà.') {
            throw $exception;
        }
    }

    adminSaveRecord($connexion, $countryEntity, ['nom_pays' => 'États-Unis'], [], 'update', ['id_pays' => 1]);
    $name = $connexion->query('SELECT nom_pays FROM PAYS WHERE id_pays = 1')->fetchColumn();
    if ($name !== 'États-Unis') {
        throw new RuntimeException('The country record was not updated.');
    }
};

$tests['la suppression distingue les lignes existantes et absentes'] = function () use ($makeCountriesDatabase, $countryEntity) {
    $connexion = $makeCountriesDatabase();
    adminSaveRecord($connexion, $countryEntity, ['nom_pays' => 'France'], [], 'create');
    if (!adminDeleteRecord($connexion, $countryEntity, ['id_pays' => 1])) {
        throw new RuntimeException('The existing country was not deleted.');
    }
    if (adminDeleteRecord($connexion, $countryEntity, ['id_pays' => 1])) {
        throw new RuntimeException('Deleting a missing country reported success.');
    }
};

$tests['une épreuve identique (sport, lieu, date, heure) est refusée'] = function () {
    $connexion = new PDO('sqlite::memory:');
    $connexion->exec('CREATE TABLE EPREUVE (id_epreuve INTEGER PRIMARY KEY AUTOINCREMENT, date_epreuve TEXT, heure_epreuve TEXT, id_lieu INTEGER, id_sport INTEGER)');
    $entity = [
        'table' => 'EPREUVE',
        'keys' => ['id_epreuve'],
        'fields' => [
            'date_epreuve' => ['label' => 'Date', 'type' => 'date', 'required' => true],
            'heure_epreuve' => ['label' => 'Heure', 'type' => 'time', 'required' => true],
            'id_lieu' => ['label' => 'Lieu', 'type' => 'select', 'required' => true],
            'id_sport' => ['label' => 'Sport', 'type' => 'select', 'required' => true],
        ],
        'unique' => [['id_sport', 'id_lieu', 'date_epreuve', 'heure_epreuve']],
    ];
    $allowed = ['id_lieu' => ['1'], 'id_sport' => ['1']];
    $input = ['date_epreuve' => '2028-07-20', 'heure_epreuve' => '14:30', 'id_lieu' => '1', 'id_sport' => '1'];
    adminSaveRecord($connexion, $entity, $input, $allowed, 'create');
    try {
        adminSaveRecord($connexion, $entity, $input, $allowed, 'create');
    } catch (RuntimeException $e) {
        return;
    }
    throw new RuntimeException('A duplicate event was accepted.');
};

$tests['la modification du résultat met à jour sa clé composée'] = function () {
    $connexion = new PDO('sqlite::memory:');
    $connexion->exec('CREATE TABLE PARTICIPER (id_athlete INTEGER NOT NULL, id_epreuve INTEGER NOT NULL, resultat TEXT NOT NULL, PRIMARY KEY (id_athlete, id_epreuve))');
    $entity = [
        'table' => 'PARTICIPER',
        'keys' => ['id_athlete', 'id_epreuve'],
        'fields' => [
            'id_athlete' => ['label' => 'Athlète', 'type' => 'select', 'required' => true],
            'id_epreuve' => ['label' => 'Épreuve', 'type' => 'select', 'required' => true],
            'resultat' => ['label' => 'Résultat', 'type' => 'text', 'required' => true],
        ],
        'unique' => [['id_athlete', 'id_epreuve']],
    ];
    $allowed = ['id_athlete' => ['1', '2'], 'id_epreuve' => ['10', '11']];
    adminSaveRecord($connexion, $entity, ['id_athlete' => '1', 'id_epreuve' => '10', 'resultat' => '10.5'], $allowed, 'create');
    adminSaveRecord($connexion, $entity, ['id_athlete' => '1', 'id_epreuve' => '11', 'resultat' => '10.2'], $allowed, 'update', ['id_athlete' => 1, 'id_epreuve' => 10]);

    $result = $connexion->query('SELECT id_athlete, id_epreuve, resultat FROM PARTICIPER')->fetch(PDO::FETCH_ASSOC);
    if ((int) $result['id_athlete'] !== 1 || (int) $result['id_epreuve'] !== 11 || $result['resultat'] !== '10.2') {
        throw new RuntimeException('The composite result key was not updated correctly.');
    }
};

$failures = 0;
foreach ($tests as $name => $test) {
    try {
        $test();
        echo "[OK] $name\n";
    } catch (Throwable $exception) {
        $failures++;
        fwrite(STDERR, "[FAIL] $name: " . $exception->getMessage() . "\n");
    }
}

printf("%d tests, %d failure(s)\n", count($tests), $failures);
exit($failures === 0 ? 0 : 1);
